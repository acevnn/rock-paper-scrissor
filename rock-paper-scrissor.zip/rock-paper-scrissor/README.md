# rock-paper-scrissor
a game of rock, paper, scrissor made with pure JS
